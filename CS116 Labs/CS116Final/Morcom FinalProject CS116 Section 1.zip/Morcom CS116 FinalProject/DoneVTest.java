public class DoneVTest
{
public static void main(String args[])
{
DoneVehicles dv=new DoneVehicles();
//create 2 Manual vehicle and 2 automatic vehicle object's
ManualVehicle mv1=new ManualVehicle();
ManualVehicle mv2=new ManualVehicle();
AutomaticVehicle av1=new AutomaticVehicle();
AutomaticVehicle av2=new AutomaticVehicle();
dv.addManual(mv1);
dv.addManual(mv2);
dv.addAutomatic(av1);
dv.addAutomatic(av2);
System.out.println(" max automatic wait :"+dv.getMaxAutomaticWait());
System.out.println(" max manual wait :"+dv.getMaxManualWait());
System.out.println(" Average automatic wait :"+dv.getAverageAutomaticWait());
System.out.println(" Average Manual wait :"+dv.getAverageManualWait());
System.out.println(" Manual Count : "+dv.manualCount());
System.out.println(" Automatic count : "+dv.automaticCount());
System.out.println(" Manual vehicle list : "+dv.getManualList());
System.out.println(" Automatic vehicle list : "+dv.getAutomaticList());
}
}