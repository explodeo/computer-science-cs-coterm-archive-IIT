public class VehicleTypeException extends Exception {
	public VehicleTypeException() { super(); }
	public VehicleTypeException(String message) { super(message); }
}